# MousePosition
Simple app to track mouse position.
